COMP454 SmartRetail raw data

lab2_initial: initial source snapshot in mixed formats: CSV, JSON, XML, and plain text.
lab3_delta: incremental/update batch for SCD and fact ETL exercises.
The data is synthetic and created for COMP454 teaching.
